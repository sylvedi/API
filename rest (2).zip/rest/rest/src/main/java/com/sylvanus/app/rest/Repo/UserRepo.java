package com.sylvanus.app.rest.Repo;

import com.sylvanus.app.rest.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User, Long> {

}
