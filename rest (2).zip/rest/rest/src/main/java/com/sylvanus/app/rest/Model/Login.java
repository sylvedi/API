package com.sylvanus.app.rest.Model;

public class Login {

}
