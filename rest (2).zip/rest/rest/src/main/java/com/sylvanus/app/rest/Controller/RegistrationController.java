package com.sylvanus.app.rest.Controller;

public class RegistrationController {

}
